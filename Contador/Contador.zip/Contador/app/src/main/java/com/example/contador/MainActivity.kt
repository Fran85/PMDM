package com.example.contador

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.View.OnClickListener
import android.widget.Button
import android.widget.TextView
import com.example.contador.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity(), OnClickListener {

    private lateinit var botonIncremento: Button;
    private lateinit var botonDecremento: Button;
    private  var botonPasar: Button?= null;
    private lateinit var textoContdor: TextView;

    private lateinit var binding: ActivityMainBinding

    private var contador: Int = 0;

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)

        setContentView(binding.root)

        contador = savedInstanceState?.getInt("contador") ?:0

//se tienen que inicializar aunque sea en nullo, si no rompe la app

        botonDecremento= findViewById(R.id.boton_decremento)
        botonIncremento= findViewById(R.id.boton_incremento)
        botonPasar= findViewById(R.id.boton_pasar)

        textoContdor= findViewById(R.id.texto_contador)
        textoContdor.text = contador.toString();

        botonIncremento.setOnClickListener (this)
        botonDecremento.setOnClickListener (this)
        botonPasar?.setOnClickListener (this)

    }

    override fun onClick(v: View?) {
        //diferenciar quien ha pulsado, si incremento o decremento
        //la interrogacion al final de algo indica que puede ser nulo
        when(v?.id){
            R.id.boton_incremento->{
                contador++
            }
            R.id.boton_decremento->{
                contador--
            }
            R.id.boton_pasar->{

            }

        }
        textoContdor.text = contador.toString()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        //lo guarda por un par clave - valor
        outState.putInt("contador",contador)
    }


    //se sobreescriben los metodos de arranque, parada, pausa...
    //son los principales, no se controlan pero se pueden sobrescribir
    override fun onStart() {
        super.onStart()
        Log.v("ciclo", "Ejecuanto onStart")
    }

    override fun onResume() {
        super.onResume()
        Log.v("ciclo", "Ejecuanto onResume")
    }

    override fun onPause() {
        super.onPause()
        Log.v("ciclo", "Ejecuanto onPause")
    }

    override fun onRestart() {
        super.onRestart()
        Log.v("ciclo", "Ejecuanto onRestart")
    }

    override fun onStop() {
        super.onStop()
        Log.v("ciclo", "Ejecuanto onStop")
    }


    override fun onDestroy() {
        super.onDestroy()
        Log.v("ciclo", "Ejecuanto onDestroy")
    }
}